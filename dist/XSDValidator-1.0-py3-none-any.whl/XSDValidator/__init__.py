from .XSDValidator import XSDValidator
from .version import VERSION
__version__ = VERSION